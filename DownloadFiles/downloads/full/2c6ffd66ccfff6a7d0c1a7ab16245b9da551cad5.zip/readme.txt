


FolderTimeUpdate v1.55
Copyright (c) 2014 - 2019 Nir Sofer
Web site: http://www.nirsoft.net



Description
===========

FolderTimeUpdate is a simple tool for Windows that scans all files and
folders under the base folder you choose, and updates the 'Modified Time'
of every folder according the latest modified time of the files stored in
it.
This tool might be useful if, for example, you backup a cluster of
folders and then restore them into another disk, but the backup program
doesn't restore the original modified time of the folders.



System Requirements
===================

This utility works on any version of Windows, starting from Windows 2000
and up to Windows 10. Both 32-bit and 64-bit systems are supported.



Versions History
================


* Version 1.55:
  o Added 'Explorer Context Menu' option. When it's turned on, you
    can right-click on a folder of Windows Explorer, choose
    'FolderTimeUpdate' from the context menu, and FolderTimeUpdate will
    be opened with this folder.
  o Fixed bug: FolderTimeUpdate failed to remember the last
    size/position of the main window if it was not located in the primary
    monitor.

* Version 1.52:
  o Increased the size of the 'Update Mode' combo-box.

* Version 1.51:
  o Fixed issue: When running FolderTimeUpdate in the first time
    without .cfg file, the window of FolderTimeUpdate was too small and
    the start button was hidden.

* Version 1.50:
  o Added 'Skip files that match the following wildcards' option.

* Version 1.46:
  o Fixed bug: FolderTimeUpdate failed to update the creation time if
    the folder had 0 files.

* Version 1.45:
  o Added 'Include time of files in all subfolders' for the 'Creation
    Time' field

* Version 1.40:
  o Added 'Set the specified time to empty folders (Local Time)'
    option (In previous versions, the 'Set the specified time to empty
    folders' option worked in GMT, now you can also use this option with
    your local time)
  o Added 'Align Numeric Columns To Right' option.

* Version 1.37:
  o Fixed FolderTimeUpdate to save the empty folder date/time value
    to the .cfg file.

* Version 1.36:
  o Added 'Set the modified time of empty folders to their created
    time' to the 'Empty Folders' option.
  o Fixed bug: When using command-line, FolderTimeUpdate saved the
    files in ANSI encoding, but Added Byte order mark of Unicode.

* Version 1.35:
  o Updating date/time of folders from command-line: You can now
    update the date/time of folders without displaying any user
    interface, for example:
    FolderTimeUpdate.exe /BaseFolder "c:\MyFiles" /scomma
    "c:\temp\updatelog.csv"
  o Added /cfg command-line parameter to load another config file
    instead of the default one (FolderTimeUpdate.cfg)
  o Fixed FolderTimeUpdate to save the current settings to the config
    file if you exit without clicking the start button.

* Version 1.31:
  o Added 'Skip files that their date/time is greater than the
    current time' option.

* Version 1.30:
  o Added option to update the creation time of folder in 3 different
    methods: Update the created time with the same value of modified
    time, update the created time accoding to the oldest created time of
    files inside the folder, or update the created time accoding to the
    oldest modified time of files inside the folder.

* Version 1.26:
  o Added 'Run As Administrator' option (Ctrl+F11), which allows you
    to easily run FolderTimeUpdate as administrator on Windows
    Vista/7/8/2008. You should use this option if you get a 'Access is
    denied' error while trying to update the folder date/time.

* Version 1.25:
  o Added option to specify one or more wildcards (delimited by
    comma) to scan. For example, if you type in this field '*.exe', only
    the .exe files will be used to calculate the modified time of the
    folder.

* Version 1.20:
  o Added 'Mark Items With Time Change' option.
  o Added 'Display only items with time change' option to the Log
    Display combo-box.

* Version 1.16:
  o Added 'Skip hidden and system files' option.

* Version 1.15:
  o Added 'Files' and 'SubFolders' columns, which display the number
    of files and subFolders in every folder.
  o Added 'Update also the base folder' option.

* Version 1.10:
  o Added browse folder button.
  o Added option to drag a folder from Explorer into FolderTimeUpdate
    window in order to choose the desired folder.
  o Added 'Open Selected Folder' option.
  o Fixed bug: Failed to show dates earlier than 1985.
  o Fixed bug with the accelerator keys.

* Version 1.01:
  o Fixed to display the main window properly when using large fonts
    settings.

* Version 1.00 - First release.



Start Using FolderTimeUpdate
============================

FolderTimeUpdate doesn't require any installation process or additional
dll files. In order to start using it, simply run the executable file -
FolderTimeUpdate.exe

After running FolderTimeUpdate, you can choose the desired base folder
and the other options and then click the 'Start' button to start updating
the modified time of all folders.
If you're not totally sure that the 'Modified Time' change is right for
you, you can choose the 'Simulation Mode' option. When 'Simulation Mode'
is on, FolderTimeUpdate will only display the changes of the modified
time that will be made for all folders, but without actually applying
these changes.



Command-Line Options
====================

Starting from version 1.35, you can update the date/time of folders from
command-line, without displaying any user interface. The result of the
folder date/time update will be saved into the specified log file.
For example, the following command will update the date/time of folders
according to the current settings (saved in the .cfg file), and the
result will be saved to c:\temp\log.csv:
FolderTimeUpdate.exe /scomma c:\temp\log.csv

You can use the /cfg command-line parameter to load another config file
instead of the default one:
FolderTimeUpdate.exe /cfg c:\temp\1.cfg /scomma c:\temp\log.csv

You can also override the settings saved in the .cfg file by specifying
the same variable name in the command-line... For example: Inside the
.cfg file, the base folder is stored as 'BaseFolder=folder', so you can
override this value by specifying the /BaseFolder in command-line.
In the following example, the base folder is set to c:\myfolder and the
sunfolders depth is set to 3:
FolderTimeUpdate.exe /BaseFolder "c:\myfolder" /SubfoldersDepth 3 /stab
c:\temp\log.txt

In the following example, FolderTimeUpdate is executed in simulation
mode, so the result is saved to a file, but without actually changing the
date/time of the folders:
FolderTimeUpdate.exe /Simulation 1 /stab c:\temp\log.txt



/cfg <Config File>
Start FolderTimeUpdate with the specified config file.

/stext <Filename>
Update the date/time of folders and save the log to a simple text file.

/stab <Filename>
Update the date/time of folders and save the log to a tab-delimited text
file.

/scomma <Filename>
Update the date/time of folders and save the log to a comma-delimited
text file (csv).

/stabular <Filename>
Update the date/time of folders and save the log to a tabular text file.

/shtml <Filename>
Update the date/time of folders and save the log to HTML file
(Horizontal).

/sverhtml <Filename>
Update the date/time of folders and save the log to HTML file (Vertical).

/sxml <Filename>
Update the date/time of folders and save the log to XML file.



Translating FolderTimeUpdate to other languages
===============================================

In order to translate FolderTimeUpdate to other language, follow the
instructions below:
1. Run FolderTimeUpdate with /savelangfile parameter:
   FolderTimeUpdate.exe /savelangfile
   A file named FolderTimeUpdate_lng.ini will be created in the folder of
   FolderTimeUpdate utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run FolderTimeUpdate, and all
   translated strings will be loaded from the language file.
   If you want to run FolderTimeUpdate without the translation, simply
   rename the language file, or move it to another folder.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via floppy disk, CD-ROM, Internet, or in any
other way, as long as you don't charge anything for this and you don't
sell it or distribute it as a part of commercial product. If you
distribute this utility, you must include all files in the distribution
package, without any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to nirsofer@yahoo.com
