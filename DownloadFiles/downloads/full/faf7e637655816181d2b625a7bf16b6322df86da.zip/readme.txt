Creating a real console application in Visual Basic
Written by Nir Sofer

Web site: http://nirsoft.mirrorz.com


Some development tools, like Visual C++ and Delphi, allows the developer to easily
create console applications. These tools provides specific methods and functions 
for writing to the console screen and their compiler also provides special option
for creating console executable. Unfortunately, Visual Basic doesn't support 
console applications. Even if you use the Win32 API for writing into the console 
screen, Your application won't work, because the Visual Basic compiler always 
creates GUI application and it doesn't provide any compiler options for changing
it to console application. 

But... with a small trick, it's possible to bypass the limitation of the
Visual Basic compiler: 
I have developed a small utility that converts an Executable file (.exe) from 
GUI application mode to console application mode. So, you can develop a console 
application in Visual Basic, create an executable file, and then, use my utility 
to convert the executable into a console application. 
My utility was developed in Visual Basic, and the source code is provided within 
the sample package. You can use it by opening the appmodechange project from 
Visual Basic IDE. 


In order to test my sample, follow the instructions below:

1. Open the console application sample (console.vbp), and create an executable
   file (console.exe) for this project.
2. Run the Application Mode Changer (appmodechange.exe), select the console.exe that 
   you created, and click the "Change Mode" button. The executable (console.exe) will be 
   switched to console mode. 
3. Open a command prompt window (MS-DOS window in Windows 95/98), and run the console.exe.
   You'll see a few lines written directly to the console window.
 


Files in this package:
readme.txt		The file you're reading now !
appmodechange.exe	The Application Mode Changer Executable.
console.exe		Console application sample.
appmodechange.vbp	The Application Mode Changer: VB project.
appmodechange.frm	The main form of the Application Mode Changer.
console.vbp		Console application sample project.
console.bas		the module of the Console application sample.
