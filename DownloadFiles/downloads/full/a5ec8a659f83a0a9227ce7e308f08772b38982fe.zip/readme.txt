***********************************
IECompo v1.00
Copyright (c) 2003 Nir Sofer

Web site: http://www.nirsoft.net
***********************************

Description
===========
This small utility displays the list of Internet Explorer components that are installed
on your computer.


License
=======
This utility is released as freeware. You can freely use and distribute it.
If you distribute this utility, you must include the readme.txt in the distribution
package, without any modification !


Disclaimer
==========
The software is provided "AS IS" without any warranty, either expressed or implied,
including, but not limited to, the implied warranties of merchantability and fitness
for a particular purpose. The author will not be liable for any special, incidental,
consequential or indirect damages due to loss of data or any other reason. 


Feedback
========
If you have any problem, suggestion, comment, or you found a bug in my utility, you can send a message to nirsofer@yahoo.com





