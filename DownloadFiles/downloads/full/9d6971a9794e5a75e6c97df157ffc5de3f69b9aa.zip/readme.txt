-------------------------------------
TurnFlash v1.00 (Command-Line Version)
Copyright (c) 2003 Nir Sofer

Web site: http://nirsoft.cjb.net
-------------------------------------

Description
===========
Many Web sites today use the Macromedia Flash component for creating animated ads.
These ads consumes additional bandwidth and sometimes even slow down your computer.
Unfortunately, Internet Explorer doesn't provide a simple way to disable the Flash
component. Furthermore, if you refuse to install the Flash component, Internet Explorer
will constantly ask you to install Flash in each time that you enter into a Web page 
that contains a Flash object. 

This utility allows you to easily disable and enable the Flash component in 
Internet Explorer browser (Version 5.00 and above). When you disable flash with this utility, 
all new windows in Internet Explorer will be opened without using the Flash component. The
disabling of Flash doesn't affect the windows that are already opened.
While the Flash Component is disabled, Internet Explorer will not ask you to download 
and install it. However, the disabling of the Flash component might cause a script error 
in some Web pages.
Be aware that in Windows NT, 2000 and XP, this utility will not work if you don't have 
permission to write to the Registry keys of Internet Explorer.

Using TurnFlash
===============
TurnFlash is a simple command-line utility that accepts only one parameter with 2 
available options: 'on' and 'off'.
In order to turn off (disable) the Flash component, run this utility with 'off' parameter:
TurnFlash.exe off

In order to turn on (enable) the Flash component, run this utility with 'on' parameter:
TurnFlash.exe on

There are also 2 simple batch files that allows you to enable/disable Flash without
using a command-line parameter:
TurnFlashOff.bat - Disables the Flash component.
TurnFlashOn.bat - Enables the Flash component.


License
=======
This utility is released as freeware. You can freely use and distribute it.
If you distribute this utility, you must include all files in the distribution package including source code, without any modification !


Disclaimer
==========
The software is provided "AS IS" without any warranty, either expressed or implied,
including, but not limited to, the implied warranties of merchantability and fitness
for a particular purpose. The author will not be liable for any special, incidental,
consequential or indirect damages due to loss of data or any other reason. 


Feedback
========
If you have any problem, suggestion, comment, or you found a bug in my utility, you can send a message to nirsofer@yahoo.com
