

IEDesignMode v1.00
Copyright (c) 2007 Nir Sofer
Web site: http://www.nirsoft.net



Description
===========

IEDesignMode Adds a new menu item into the context menu of Internet
Explorer that allows you to easily switch the active Internet Explorer
window to design mode.
When a Web page in in design mode, you can change the location of images
and other objects, change the current text, paste a new text into the Web
page, and so on. After you made your changes, you can easily switch back
to non-design mode and/or save the modified Web page to HTML file.



System Requirements
===================


* Windows 98/ME/2000/XP/2003/Vista
* Internet Explorer 6.x or 7.x



Start Using IEDesignMode
========================

In order to start using this utility, just copy the executable
(IEDesignMode.exe) to any folder you like, and run it. After you run it,
we'll be asked if you want to add the new menu item to Internet Explorer
context menu. Choosing the 'Yes' answer will add the 'Design Mode' menu
item to your Internet Explorer. If you want to remove the 'Design Mode'
item, simply run IEDesignMode again, and it'll offer you to remove this
menu item.

After you chose to add the 'Design Mode' menu item, run Internet
Explorer, browse into a Web site, or open a local HTML file. Right-click
the window of Internet Explorer, and choose 'Design Mode' from the
context menu. Now you're running in design mode, and you can change the
text, move images/objects to another location, and so on.
In order to return back to non-design mode, choose 'Browse View' from the
context menu. You can also save the current page with yours changes into
HTML file by using the 'Save As' option. However, be aware that you must
save the Web page as 'HTML Only'. If you save a complete Web page, you
changes won't be saved.



License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via floppy disk, CD-ROM, Internet, or in any
other way, as long as you don't charge anything for this. If you
distribute this utility, you must include all files in the distribution
package, without any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to nirsofer@yahoo.com
